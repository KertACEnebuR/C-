﻿namespace LaptopsGUI
{
    public partial class MainWindow
    {
        internal class Category
        {
            public int CategoryCode { get; set; }
            public string CategoryName { get; set; }

            public Category(int CategoryC, string CategoryN)
            {
                CategoryCode = CategoryC;
                CategoryName = CategoryN;
            }
        }
    }
}