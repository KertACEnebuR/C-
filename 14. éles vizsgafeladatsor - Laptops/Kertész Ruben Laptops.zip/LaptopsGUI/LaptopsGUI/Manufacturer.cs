﻿namespace LaptopsGUI
{
    public partial class MainWindow
    {
        internal class Manufacturer
        {
            public int ManufacturerCode { get; set; }
            public string ManufacturerName { get; set; }

            public Manufacturer(int ManufacturerC, string ManufacturerN)
            {
                ManufacturerCode = ManufacturerC;
                ManufacturerName = ManufacturerN;
            }
        }
    }
}