﻿// See https://aka.ms/new-console-template for more information

public class Versenyzok
{
    public string Nev { get; set; }
    public List<int> Pontozas;

    public Versenyzok(string s)
    {
        var l = s.Split(';');
        Nev = l[0];
        Pontozas = new List<int>();

        string[] pontok = l[1].Split(' ');

        for (int i = 0; i < pontok.Length; i++)
        {
            Pontozas.Add(int.Parse(pontok[i]));
        }
    }
}


