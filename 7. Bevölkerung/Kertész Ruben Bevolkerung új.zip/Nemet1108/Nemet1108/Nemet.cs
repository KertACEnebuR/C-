﻿namespace Nemet1108
{
    public partial class MainWindow
    {
        public class Nemet
        {
            public int Id { get; set; }
            public string Nem { get; set; }
            public int SzuletesiEv { get; set; }
            public int Suly { get; set; }
            public int Magassag { get; set; }
            public bool Dohanyzik { get; set; }
            public string Nemzetiseg { get; set; }
            public string Nepcsoport { get; set; }
            public string Tartomany { get; set; }
            public int NettoJovedelem { get; set; }
            public string IskolaiVegzettseg { get; set; }
            public string PolitikaiNezet { get; set; }
            public bool AktivSzavazo { get; set; }
            public string SorFogyasztasEvente { get; set; }     //int
            public string KrumpliFogyasztasEvente { get; set; }     //int

            public Nemet(string s)
            {
                var r = s.Split(';');
                Id = int.Parse(r[0]);
                Nem = r[1];
                SzuletesiEv = int.Parse(r[2]);
                Suly = int.Parse(r[3]);
                Magassag = int.Parse(r[4]);
                Dohanyzik = r[5] == "igen";
                Nemzetiseg = r[6];
                if (Nemzetiseg == "német")
                {
                    Nepcsoport = r[7];
                }
                else
                {
                    Nepcsoport = "";
                }
                Tartomany = r[8];
                NettoJovedelem = int.Parse(r[9]);
                if (IskolaiVegzettseg == null)
                {
                    IskolaiVegzettseg = "";
                }
                else
                {
                    IskolaiVegzettseg = r[10];
                }
                PolitikaiNezet = r[11];
                AktivSzavazo = r[12] == "igen";
                if (SorFogyasztasEvente != "NA")
                {
                    SorFogyasztasEvente = r[13];    //int.Parse(r[13]);
                }
                else
                {
                    SorFogyasztasEvente = r[13];
                }

                if (KrumpliFogyasztasEvente != "NA")
                {
                    KrumpliFogyasztasEvente = r[14];    //int.Parse(r[14]);
                }
                else
                {
                    KrumpliFogyasztasEvente = r[14];
                }
            }

            public override string ToString()
            {
                return $"{Id}; {Nem}; {SzuletesiEv}; {Suly}; {Magassag}; {Dohanyzik}; {Nemzetiseg}; {Nepcsoport}; {Tartomany}; {NettoJovedelem}; {IskolaiVegzettseg}; {PolitikaiNezet}; {AktivSzavazo}; {SorFogyasztasEvente}; {KrumpliFogyasztasEvente};";
            }
        }
    }
}