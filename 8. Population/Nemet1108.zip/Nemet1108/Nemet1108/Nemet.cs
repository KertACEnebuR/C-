﻿namespace BevölkerungGUI
{
    public partial class MainWindow
    {
        public class Allampolgar
        {
            public int Id { get; set; }
            public string Nem { get; set; }
            public int SzuletesiEv { get; set; }
            public int Suly { get; set; }
            public int Magassag { get; set; }
            public bool Dohanyzik { get; set; }
            public string DohanyzikText { get; set; }
            public string Nemzetiseg { get; set; }
            public string Nepcsoport { get; set; }
            public string Tartomany { get; set; }
            public int NettoJovedelem { get; set; }
            public string IskolaiVegzettseg { get; set; }
            public string PolitikaiNezet { get; set; }
            public bool AktivSzavazo { get; set; }
            public string AktivszavazoText { get; set; }
            public int SorFogyasztasEvente { get; set; }
            public string SorFogyasztasEventeText { get; set; }
            public int KrumpliFogyasztasEvente { get; set; }
            public string KrumpliFogyasztasEventeText { get; set; }
            public int Eletkor => DateTime.Today.Year - SzuletesiEv;
            public double HaviJovedelem => NettoJovedelem / 12;

            public Allampolgar(string s)
            {
                var r = s.Split(';');
                Id = int.Parse(r[0]);
                Nem = r[1];
                SzuletesiEv = int.Parse(r[2]);
                Suly = int.Parse(r[3]);
                Magassag = int.Parse(r[4]);
                DohanyzikText = r[5];
                Dohanyzik = r[5] == "igen" ? true : false;
                Nemzetiseg = r[6];
                Nepcsoport = string.IsNullOrEmpty(r[7]) ? "" : r[7];   
                Tartomany = r[8];
                NettoJovedelem = int.Parse(r[9]);
                IskolaiVegzettseg = string.IsNullOrEmpty(r[10]) ? "" : r[10];
                PolitikaiNezet = r[11];
                AktivszavazoText = r[12];
                AktivSzavazo = r[12] == "igen" ? true : false;
                SorFogyasztasEventeText = r[13];
                if (SorFogyasztasEventeText == "NA")
                {
                    SorFogyasztasEvente = -1;
                }
                else
                {
                    SorFogyasztasEvente = int.Parse(r[13]);
                }

                KrumpliFogyasztasEventeText = r[14];
                if (KrumpliFogyasztasEventeText == "NA")
                {
                    KrumpliFogyasztasEvente = -1;
                }
                else
                {
                    KrumpliFogyasztasEvente = int.Parse(r[14]);                 
                }
            }

            public string ToString(bool parameter)
            {
                if (parameter == true)
                {
                    return $"{Id}\t{Nem}\t{SzuletesiEv}\t{Suly}\t{Magassag}";
                }
                else
                {
                    return $"{Id}\t{Nemzetiseg}\t{Nepcsoport}\t{Tartomany}\t{NettoJovedelem}";
                }
            }      
        }
    }
}