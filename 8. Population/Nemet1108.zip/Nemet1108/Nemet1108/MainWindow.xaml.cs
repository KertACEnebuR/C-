﻿using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static BevölkerungGUI.MainWindow;

namespace BevölkerungGUI

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Allampolgar> lakossag = new List<Allampolgar>();
        Random rnd = new Random();
        public MainWindow()
        {
            InitializeComponent();

            MegoldasTeljes.ItemsSource = lakossag;

            foreach (var item in File.ReadAllLines(@"..\..\..\SRC\bevölkerung.txt").Skip(1))
            {
                lakossag.Add(new Allampolgar(item));
            }

            int i = 1;

            while (i < 46)
            {
                cmb_feladatok.Items.Add($"{i}.");
                i++;
            }
            
        }

        private void Feladat1()
        {
            //1.feladat

            double LegnagyobbEvesNettoJovedelem = lakossag
                .OrderByDescending(a => a.NettoJovedelem)
                .Select(a => a.NettoJovedelem)
                .First();

            MegoldasMondatos_valasz.Content = $"A legnagyobb nettó éves jövedelem {LegnagyobbEvesNettoJovedelem} euró.";
        }

        private void Feladat2()
        {
            //2.feladat

            double AtlagEvesJovedelem = lakossag
                .Average(a => a.NettoJovedelem);

            MegoldasMondatos_valasz.Content = $"Az átlagos nettó éves jövedelem {Math.Round(AtlagEvesJovedelem, 2)} euró.";
        }

        private void Feladat3()
        {
            //3.feladat

            var TartomanyRendezes = lakossag
                .GroupBy(a => a.Tartomany)
                .Select(t => new
                {
                    Nev = t.Key,
                    Letszam = t.Count()
                });

            string Kiiras = "";
            foreach (var tartomany in TartomanyRendezes)
            {
                Kiiras += $"Tartomány: {tartomany.Nev}, létszám: {tartomany.Letszam}\n";
            }

            MegoldasLista.Items.Add(Kiiras);
        }

        private void Feladat4()
        {
            //4.feladat

            List<Allampolgar> AngolaiAllampolgarokLista = lakossag
                .Where(a => a.Nemzetiseg == "angolai")
                .Select(a => a)
                .ToList();

            MegoldasTeljes.ItemsSource = AngolaiAllampolgarokLista;
        }

        private void Feladat5()
        {
            //5.feladat
            int LegfiatalabbEletkor = lakossag
                .Min(a => a.Eletkor);

            List<Allampolgar> LegfiatalabbLista = lakossag
                .Where(a => a.Eletkor == LegfiatalabbEletkor)
                .Select(e => e)
                .ToList();

            MegoldasTeljes.ItemsSource = LegfiatalabbLista;
        }

        private void Feladat6()
        {
            //6.feladat

            var NemDohanyzokLista = lakossag
                .Where(a => a.DohanyzikText == "nem")
                .Select(a => new 
                { 
                    id = a.Id, 
                    havijovedelem = a.HaviJovedelem 
                })
                .ToList();

            for (int i = 0; i < NemDohanyzokLista.Count; i++)
            {
                MegoldasLista.Items.Add($"Id: {NemDohanyzokLista[i].id}, havi jövedelem: {NemDohanyzokLista[i].havijovedelem}");
            }
            
        }

        private void Feladat7()
        {
            //7.feladat

            List<Allampolgar> BajorLista = lakossag
                .Where(a => a.Tartomany == "Bajorország" && a.NettoJovedelem > 30000)
                .OrderBy(t => t.IskolaiVegzettseg)
                .Select(a => a)
                .ToList();

            MegoldasTeljes.ItemsSource = BajorLista;
        }

        private void Feladat8()
        {
            //8.feladat

            var Ferfiak = lakossag
                .Where(a => a.Nem == "férfi")
                .Select(a => a.ToString(true));

            foreach (var item in Ferfiak)
            {
                Console.WriteLine(item);
            }
        }

        private void Feladat9()
        {
            //9.feladat
            var BajorNokLista = lakossag
                .Where(a => a.Tartomany == "Bajorország" && a.Nem == "nő")
                .Select(t => t.ToString(false));

            foreach (var item in BajorNokLista)
            {
                MegoldasLista.Items.Add(item);
            }
        }

        private void Feladat10()
        {
            //10.feladat

            List<Allampolgar> NemdohanyzoTizesLista = lakossag
                .Where(a => a.DohanyzikText == "nem")
                .OrderByDescending(t => t.HaviJovedelem)
                .Select(a => a)
                .Take(10)
                .ToList();

            MegoldasTeljes.ItemsSource = NemdohanyzoTizesLista;
        }

        private void Feladat11()
        {
            //11.feladat

            List<Allampolgar> LegidosebbOtosLista = lakossag
                .OrderByDescending(t => t.Eletkor)
                .Take(5)
                .ToList();

            MegoldasTeljes.ItemsSource = LegidosebbOtosLista;
        }

        private void Feladat12()
        {
            //12.feladat

            var nemetCsoportositas = lakossag
                .Where(a => a.Nemzetiseg == "német")
                .GroupBy(a => a.Nepcsoport)
                .Select(e => new
                {
                    NepcsoportNev = e.Key,
                    Allampolgarok = e.Select(a => new
                    {
                        AktivSzavazo = a.AktivSzavazo ? "aktív szavazó" : "nem aktív szavazó",
                        PolitikaiNezet = a.PolitikaiNezet
                    }).ToList()
                }).ToList();

            foreach (var item in nemetCsoportositas)
            {
                MegoldasLista.Items.Add($"Népcsoport: {item.NepcsoportNev}");

                foreach (var item2 in item.Allampolgarok)
                {
                    MegoldasLista.Items.Add($"\t- {item2.AktivSzavazo}, {item2.PolitikaiNezet}");
                }
            }

        }

        private void Feladat13()
        {
            //13.feladat

            double AtlagosFerfiSorFogyasztas = lakossag
                .Where(a => a.Nem == "férfi")
                .Average(t => t.SorFogyasztasEvente);

            MegoldasMondatos_valasz.Content = $"A férfiak átlagos éves sörfogyasztása {Math.Round(AtlagosFerfiSorFogyasztas, 2)} liter.";
        }

        private void Feladat14()
        {
            //14.feladat

            var VegzettsegCsoportositas = lakossag
                .OrderBy(a => a.IskolaiVegzettseg)
                .GroupBy(a => a.IskolaiVegzettseg)
                .ToList();

            foreach (var item in VegzettsegCsoportositas)
            {
                MegoldasLista.Items.Add($"Iskolai végzettség: {item.Key}");

                foreach (var item2 in item)
                {
                    MegoldasLista.Items.Add($"\n- {item2.Id}: {item2.Nem}, {item2.SzuletesiEv}, {item2.PolitikaiNezet}");
                }
            }
        }

        private void Feladat15()
        {
            //15.feladat

            var LegmagasabbJovedelem = lakossag
                .OrderBy(a => a.NettoJovedelem)
                .TakeLast(3)
                .Select(a => a.ToString(false));

            var LegkisebbJovedelem = lakossag
                .OrderBy(a => a.NettoJovedelem)
                .Take(3)
                .Select(a => a.ToString(false));

            MegoldasLista.Items.Add("A 3 legmagasabb jövedelmű állampogár: ");

            foreach (var item in LegmagasabbJovedelem)
            {
                MegoldasLista.Items.Add($"\n- {item}");
            }

            MegoldasLista.Items.Add("A 3 legisebb jövedelmű állampogár: ");

            foreach (var item in LegkisebbJovedelem)
            {
                MegoldasLista.Items.Add($"\n- {item}");
            }
        }

        private void Feladat16()
        {
            //16.feladat

            double SzamvazokSzama = lakossag
                .Where(a => a.AktivszavazoText == "igen")
                .Count();

            MegoldasMondatos_valasz.Content = $"Az aktív szavazók százaléka {Math.Round((SzamvazokSzama / lakossag.Count) * 100, 2)} %";
        }

        private void Feladat17()
        {
            //17.feladat

            var AktivSzavazokCsoportositas = lakossag
                .Where(a => a.AktivSzavazo)
                .OrderBy(a => a.Tartomany)
                .GroupBy(a => a.Tartomany)
                .ToList();

            foreach (var item in AktivSzavazokCsoportositas)
            {
                MegoldasLista.Items.Add($"Tartomány: {item.Key}");

                foreach (var item2 in item)
                {
                    MegoldasLista.Items.Add(
                       $"  - Id: {item2.Id}, Nem: {item2.Nem}, Születési év: {item2.SzuletesiEv}, " +
                       $"Súly: {item2.Suly}, Magasság: {item2.Magassag}, Dohányzik: {item2.DohanyzikText}, " +
                       $"Nemzetiség: {item2.Nemzetiseg}, Népcsoport: {item2.Nepcsoport}, Tartomány: {item2.Tartomany}, " +
                       $"Nettó jövedelem: {item2.NettoJovedelem}, Iskolai végzettség: {item2.IskolaiVegzettseg}, " +
                       $"Politikai nézet: {item2.PolitikaiNezet}, Aktív szavazó: {item2.AktivszavazoText}, " +
                       $"Sörfogyasztás évente: {item2.SorFogyasztasEventeText}, Krumplifogyasztás évente: {item2.KrumpliFogyasztasEventeText}"
                    );
                }
            }
        }

        private void Feladat18()
        {
            //18.feladat

            double AtlagEletkor = lakossag.Average(a => a.Eletkor);

            MegoldasMondatos_valasz.Content = $"A lakosság átlagéletkora {Math.Round(AtlagEletkor, 2)} ";
        }

        private void Feladat19()
        {
            //19.feladat

            var LegmagasabbAtlagosJovedelemTartomanyLista = lakossag
                .GroupBy(a => a.Tartomany)
                .Select(a => new
                {
                    TNev = a.Key,
                    AtlagJovedelem = a.Average(t => t.NettoJovedelem),
                    FoSzam = a.Count()
                })
                .ToList();

            double LegnAtlag = LegmagasabbAtlagosJovedelemTartomanyLista
                .Max(a => a.AtlagJovedelem);

            var LegmagasabbEredmeny = LegmagasabbAtlagosJovedelemTartomanyLista
                .Where(a => a.AtlagJovedelem == LegnAtlag)
                .OrderByDescending(a => a.FoSzam)
                .First();

            MegoldasMondatos_valasz.Content = $"Tartomány: {LegmagasabbEredmeny.TNev}, Átlagos nettó jövedelem: {Math.Round(LegmagasabbEredmeny.AtlagJovedelem, 2)}, Létszám: {LegmagasabbEredmeny.FoSzam}";
        }

        private void Feladat20()
        {
            //20.feladat

            double AtlagSuly = lakossag
                .Average(a => a.Suly);

            List<int> SulyLista = lakossag
                .Select(s => s.Suly)
                .OrderByDescending(s => s)
                .ToList();

            int MedianSzamitas = SulyLista.Count;
            double Median;

            if (MedianSzamitas % 2 == 0)
            {
                Median = (SulyLista[MedianSzamitas / 2 - 1] + SulyLista[MedianSzamitas / 2]) / 2;
            }

            else
            {
                Median = SulyLista[MedianSzamitas / 2];
            }

            MegoldasMondatos_valasz.Content = $"A súlyok átlaga {Math.Round(AtlagSuly, 2)} kg a medián pedig {Median} kg.";
        }

        private void Feladat21()
        {
            //21.feladat

            int SzavazoSorfogyasztas = lakossag
                .Where(t => t.AktivszavazoText == "igen")
                .Sum(a => a.SorFogyasztasEvente);

            int NemSzavazoSorfogyasztas = lakossag
                .Where(t => t.AktivszavazoText == "nem")
                .Sum(a => a.SorFogyasztasEvente);

            if (SzavazoSorfogyasztas > NemSzavazoSorfogyasztas)
            {
                MegoldasMondatos_valasz.Content = $"A szavazók sörfogyasztása ({SzavazoSorfogyasztas} L) mint a nem szavazóké ({NemSzavazoSorfogyasztas} L).";
            }

            else
            {
                MegoldasMondatos_valasz.Content = $"A nem szavazók sörfogyasztása ({NemSzavazoSorfogyasztas} L) mint a szavazóké ({SzavazoSorfogyasztas} L).";
            }

        }

        private void Feladat22()
        {
            //22.feladat

            double FerfiMagassagAtlag = lakossag
                .Where(t => t.Nem == "férfi")
                .Average(a => a.Magassag);

            double NoiMagassagAtlag = lakossag
                .Where(t => t.Nem == "nő")
                .Average(a => a.Magassag);

            MegoldasMondatos_valasz.Content = $"Az átlagos férfi magasság {Math.Round(FerfiMagassagAtlag, 2)} cm, a női pedig {Math.Round(NoiMagassagAtlag, 2)} cm.";
        }

        private void Feladat23()
        {
            //23.feladat

            var NepcsoportRendezes = lakossag
                .GroupBy(a => a.Nepcsoport)
                .Select(t => new
                {
                    Nev = t.Key,
                    FoSzam = t.Count(),
                    EletkorAtlag = t.Average(a => a.Eletkor)
                });

            var NepcsoportFoSzamMax = NepcsoportRendezes.Max(e => e.FoSzam);

            var LegnagyobbLetszamNepcsoport = NepcsoportRendezes
                .Where(t => t.FoSzam == NepcsoportFoSzamMax)
                .OrderByDescending(t => t.EletkorAtlag)
                .First();

            MegoldasMondatos_valasz.Content = $"A legnagyobb létszámú népcsoport a {LegnagyobbLetszamNepcsoport.Nev}, a létszáma pedig {LegnagyobbLetszamNepcsoport.FoSzam}.";


        }

        private void Feladat24()
        {
            //24.feladat

            double DohanyzoJovedelemAtlag = lakossag
                .Where(t => t.DohanyzikText == "igen")
                .Average(a => a.NettoJovedelem);

            double NemDohanyzoJovedelemAtlag = lakossag
                .Where(t => t.DohanyzikText == "nem")
                .Average(a => a.NettoJovedelem);

            if (DohanyzoJovedelemAtlag > NemDohanyzoJovedelemAtlag)
            {
                MegoldasMondatos_valasz.Content = $"A dohányzók nettó éves jövedelme ({Math.Round(DohanyzoJovedelemAtlag, 2)} Ft) több mint a nem dohányzóké ({Math.Round(NemDohanyzoJovedelemAtlag, 2)} Ft).";
            }

            else
            {
                MegoldasMondatos_valasz.Content = $"A nem dohányzók nettó éves jövedelme ({Math.Round(NemDohanyzoJovedelemAtlag, 2)} Ft) több mint a dohányzóké ({Math.Round(DohanyzoJovedelemAtlag, 2)} Ft).";
            }
        }

        private void Feladat25()
        {
            //25.feladat

            double AtlagosKrumpliFogyasztas = lakossag
                .Average(a => a.KrumpliFogyasztasEvente);
            int szam = 0;

            List<Allampolgar> AtlagFelettiLista = lakossag
                .Select(a => a)
                .Where(t => t.KrumpliFogyasztasEvente > AtlagosKrumpliFogyasztas)
                .Take(15)
                .ToList();

            MegoldasMondatos_valasz.Content = $"Az átlagos krumplifogyasztás {Math.Round(AtlagosKrumpliFogyasztas, 2)}"; 
            MegoldasTeljes.ItemsSource = AtlagFelettiLista;
        }

        private void Feladat26()
        {
            //26.feladat

            var TartomanyRendezes = lakossag
                .GroupBy(a => a.Tartomany)
                .Select(t => new
                {
                    Nev = t.Key,
                    EletkorAtlag = t.Average(a => a.Eletkor)
                });

            foreach (var item in TartomanyRendezes)
            {
                MegoldasLista.Items.Add($"Tartomány: {item.Nev} Átlagéletkor: {Math.Round(item.EletkorAtlag, 2)}");
            }         
        }

        private void Feladat27()
        {
            //27.feladat

            var OtvenEvFelett = lakossag
                .Where(f => f.Eletkor > 50)
                .Select(a => a.ToString(true))
                .ToList();

            foreach (var item in OtvenEvFelett)
            {
                MegoldasLista.Items.Add(item);
            }

            MegoldasMondatos_valasz.Content = $"Db: {OtvenEvFelett.Count()} (nincs 50 éves vagy nagyobb állampolgár)";
        }

        private void Feladat28()
        {
            //28.feladat

            var DohanyzoNok = lakossag
                .Where(a => a.Nem == "nő" && a.DohanyzikText == "igen")
                .Select(a => a.ToString(false))
                .ToList();

            if (DohanyzoNok.Any())
            {
                double LegnagyobbJovedelem = lakossag
                    .Where(a => a.Nem == "nő" && a.DohanyzikText == "igen")
                    .Max(a => a.NettoJovedelem);

                foreach (var item in DohanyzoNok)
                {
                    MegoldasLista.Items.Add(item);
                }

                MegoldasMondatos_valasz.Content = $"A legnagyobb nettó jövedelem: {LegnagyobbJovedelem} Ft";
            }
            else
            {
                MegoldasMondatos_valasz.Content = "Nincsenek dohányzó nők a listában.";
            }
        }

        private void Feladat29()
        {
            //29.feladat

            var TartomanyRendezes = lakossag
                .GroupBy(a => a.Tartomany)
                .Select(t => new
                {
                    Nev = t.Key,
                    LegnagyobbFogyasztas = t.Max(a => a.SorFogyasztasEvente),
                    LegnagyobbFogyasztoId = t.OrderByDescending(a => a.SorFogyasztasEvente).Select(a => a.Id).First(),
                });

            foreach (var item in TartomanyRendezes)
            {
                MegoldasLista.Items.Add($"Tartomány: {item.Nev}, Lakos Id-je: {item.LegnagyobbFogyasztoId}, Fogyasztás: {item.LegnagyobbFogyasztas}");
            }
        }

        private void Feladat30()
        {
            //30.feladat

            var LegidosebbFerfi = lakossag
                .Where(a => a.Nem == "férfi")
                .OrderByDescending(a => a.Eletkor)
                .Select(a => a.ToString(false))
                .First();

            var LegidosebbNo = lakossag
                .Where(a => a.Nem == "nő")
                .OrderByDescending(a => a.Eletkor)
                .Select(a => a.ToString(false))
                .First();

            MegoldasLista.Items.Add($"Legidősebb férfi: {LegidosebbFerfi}");
            MegoldasLista.Items.Add($"Legidősebb nő: {LegidosebbNo}");
        }

        private void Feladat31()
        {
            //31.feladat

            List<string> Nemzeisegek = lakossag
                .OrderByDescending(s => s.Nemzetiseg)
                .Select(a => a.Nemzetiseg)
                .Distinct()
                .ToList();

            for (int i = 0; i < Nemzeisegek.Count; i++)
            {
                MegoldasLista.Items.Add(Nemzeisegek[i]);
            }
        }

        private void Feladat32()
        {
            //32.feladat

            var TartomanyRendezes = lakossag
                .GroupBy(a => a.Tartomany)
                .Select(t => new {
                    TartomanyNev = t.Key,
                    Letszam = t.Count()
                })
                .OrderBy(t => t.Letszam)
                .ToList();

            foreach (var item in TartomanyRendezes)
            {
                MegoldasLista.Items.Add(item.TartomanyNev);
            }
        }

        private void Feladat33()
        {
            //33.feladat

            List<Allampolgar> Nemzeisegek = lakossag
                .OrderByDescending(s => s.NettoJovedelem)
                .Take(3)
                .ToList();


            for (int i = 0; i < Nemzeisegek.Count; i++)
            {
                MegoldasLista.Items.Add($"Id: {Nemzeisegek[i].Id}, Jövedelem: {Nemzeisegek[i].NettoJovedelem}");
            }
        }

        private void Feladat34()
        {
            //34.feladat

            double Krumpli55felettAtlagSuly = lakossag
                .Where(a => a.Nem == "férfi" && a.KrumpliFogyasztasEvente > 55)
                .Average(a => a.Suly);

            MegoldasMondatos_valasz.Content += $"Az 55 kg krumpli felett fogyasztó férfiak átlagos súlya {Math.Round(Krumpli55felettAtlagSuly, 2)} kg.";
        }

        private void Feladat35()
        {
            //35.feladat

            var TartomanyRendezes = lakossag
                .GroupBy(a => a.Tartomany)
                .Select(t => new
                {
                    TNev = t.Key,
                    MinEv = t.Min(a => a.Eletkor)
                });

            foreach (var item in TartomanyRendezes)
            {
                MegoldasLista.Items.Add($"Tartomány: {item.TNev} Minimum év: {item.MinEv}");
            }

        }

        private void Feladat36()
        {
            //36.feladat

            var Csoportositas = lakossag
                .GroupBy(a => a.Nemzetiseg)
                .Select(t => new
                {
                    Nev = t.Key,
                    Tartomanyok = t.Select(a => a.Tartomany).Distinct()
                })
                .ToList();

            foreach (var item in Csoportositas)
            {
                foreach (var item2 in item.Tartomanyok)
                {
                    MegoldasLista.Items.Add($"A nemzetiség: {item.Nev}, a tartomány: {item2}");
                }
            }
        }

        private void Feladat37()
        {
            //37.feladat

            double atlagJovedelem = lakossag.Average(a => a.NettoJovedelem);

            var magasabbJovedelem = lakossag
                .Where(a => a.NettoJovedelem > atlagJovedelem)
                .Select(a => a.ToString(false))
                .ToList();

            MegoldasMondatos_valasz.Content = $"Az átlagos nettó jövedelem: {Math.Round(atlagJovedelem, 2)} Ft, db {magasabbJovedelem.Count}";

            foreach (var item in magasabbJovedelem)
            {
                MegoldasLista.Items.Add(item);
            }
        }

        private void Feladat38()
        {
            //38.feladat

            int FerfiakSzama = lakossag
                .Where(a => a.Nem == "férfi")
                .Count();

            int NokSzama = lakossag
                .Where(a => a.Nem == "nő")
                .Count();

            MegoldasMondatos_valasz.Content = $"A férfiak száma {FerfiakSzama} fő, a nőké pedig {NokSzama} fő.";
        }

        private void Feladat39()
        {
            //39.feladat

            var Csoportositas = lakossag
                 .GroupBy(a => a.Tartomany)
                 .Select(t => new
                 {
                     Nev = t.Key,
                     JovedelemMax = t.Max(a => a.NettoJovedelem)
                 });

            var Csokkeno = Csoportositas
                .OrderByDescending(t => t.JovedelemMax)
                .ToList();

            for (int i = 0; i < Csoportositas.Count(); i++)
            {
                MegoldasLista.Items.Add($"{Csokkeno[i].Nev}, {Csokkeno[i].JovedelemMax}");
            }
        }

        private void Feladat40()
        {
            //40.feladat

            double Nemetek = lakossag
                .Where(a => a.Nemzetiseg == "német")
                .Sum(a => a.HaviJovedelem);

            double NemNemetek = lakossag
                .Where(a => a.Nemzetiseg != "német")
                .Sum(a => a.HaviJovedelem);

            MegoldasMondatos_valasz.Content = $"Az arány {Math.Round(Nemetek / NemNemetek * 100)}%.";
        }

        private void Feladat41()
        {
            //41.feladat        
            List<Allampolgar> Torokok = lakossag
            .Where(a => a.Nemzetiseg == "török" && a.AktivSzavazo)
            .ToList();

            List<Allampolgar> VegsoLista = Torokok
            .OrderBy(a => rnd.Next())
            .Take(Math.Min(Torokok.Count, 10))
            .ToList();
            
            if (VegsoLista.Count == 0)
            {
                MegoldasMondatos_valasz.Content = "Nincs török aktív szavazó.";
            }
            else
            {
                MegoldasTeljes.ItemsSource = VegsoLista;
            }
        }

        private void Feladat42()
        {
            //42.feladat

            double AtlagSorFogy = lakossag
                .Average(a => a.SorFogyasztasEvente);

            List<Allampolgar> AtlagFelettPolgarok = lakossag
                .Where(t => t.SorFogyasztasEvente > AtlagSorFogy)
                .Select(a => a)
                .ToList();

            var Veletlenpolgarok = AtlagFelettPolgarok
                .OrderBy(a => rnd.Next())
                .Select(t => t.ToString(true))
                .Take(5);

            foreach (var item in Veletlenpolgarok)
            {
                MegoldasLista.Items.Add(item);
            }

            MegoldasMondatos_valasz.Content = $"Az átlag sörfogyasztás: {Math.Round(AtlagSorFogy, 2)} L";
        }

        private void Feladat43()
        {
            //43.feladat

            var TartomanyRendezes = lakossag
                .GroupBy(t => t.Tartomany)
                .Select(a => new
                {
                    Nev = a.Key,
                    LegkJov = a.Min(t => t.NettoJovedelem)
                });

            double AtlagJov = lakossag
                .Average(t => t.NettoJovedelem);

            var VeletlenTartomany = TartomanyRendezes
                .Where(t => t.LegkJov > AtlagJov)
                .OrderBy(t => rnd.Next())
                .Take(2)
                .ToList();

            foreach (var item in VeletlenTartomany)
            {
                MegoldasLista.Items.Add($"Tartomány: {item.Nev}, Legkisebb nettó jövedelem: {item.LegkJov}");
            }

            MegoldasMondatos_valasz.Content = $"Az átlagos nettó jövedelem: {Math.Round(AtlagJov, 2)}";
        }

        private void Feladat44()
        {
            //44.feladat

            List<Allampolgar> IskolaiVegNull = lakossag
                .Where(a => a.IskolaiVegzettseg == "")
                .Select(a => a)
                .ToList();

            var RandomIskolaVegNull = IskolaiVegNull
                .OrderBy(t => rnd.Next())
                .Take(3);

            MegoldasTeljes.ItemsSource = RandomIskolaVegNull;
        }

        private void Feladat45()
        {
            //45.feladat

            List<Allampolgar> EgyetemiVegNok = lakossag
                .Where(a => a.IskolaiVegzettseg == "Universität" && a.Nem == "nő" && a.Nepcsoport != "bajor")
                .OrderBy(a => a.Id)
                .Take(5)
                .Select(t => t)
                .ToList();

            int ElsoNoJovedelem = EgyetemiVegNok[0].NettoJovedelem;

            var NemetNok = lakossag
                .Where(a => a.Nemzetiseg == "német" && a.Nem == "nő" && a.NettoJovedelem > ElsoNoJovedelem)
                .OrderBy(a => rnd.Next())
                .Select(a => a.ToString(true))
                .Take(3);

            MegoldasTeljes.ItemsSource = EgyetemiVegNok;

            foreach (var item in NemetNok)
            {
                MegoldasLista.Items.Add(item);
            }
        }

        private void cmb_feladatok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MegoldasMondatos_valasz.Content = "";
            MegoldasLista.Items.Clear();
            MegoldasTeljes.ItemsSource = null;

            var methodName = $"Feladat{cmb_feladatok.SelectedIndex + 1}";
            var method = GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance); //Ez a sor megkeresi a metódust az osztályban a megadott methodName névvel. A BindingFlags.NonPublic azt jelzi, hogy a nem publikus metódusokat is keresi, és a BindingFlags.Instance azt jelzi, hogy az aktuális példány metódusait keresi.
            method?.Invoke(this, null); // Feltételezzük, hogy a metódus mindig elérhető Ha a metódus megtalálható, akkor meghívja azt az aktuális példányra (this) null paraméterrel. A ?. operátor biztosítja, hogy csak akkor próbálja meg meghívni a metódust, ha az valóban létezik.
        }
    }
}